Compile with: pdflatex main.tex (twice) or tectonic main.tex. Class: IEEEtran v1.8b (CTAN).
